<html>
 <head>
  <title>My First PHP Program</title>
 </head>
 <body>
<?php
echo "<h1>I'm a lumberjack.</h1>";
echo "<h2>And I'm okay.</h2>";
?>
 </body>
</html>
<div style="text-align: center">
 <p>Welcome to my movie review site!<br/>
<?php
date_default_timezone_set('America/New_York');
echo 'Today is ';
echo date('F d');
echo ', ';
echo date('Y');
?>
 <br/>
</div>
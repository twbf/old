<?php
$flavors[] = 'blue raspberry';
$flavors[] = 'root beer';
$flavors[] = 'pineapple';

sort($flavors);
print_r($flavors);
?>
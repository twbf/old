<html>
 <head>
  <title>Thank You</title>
 </head>
 <body>
<?php
require 'db.inc.php';

$db = mysql_connect(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD) or
    die ('Unable to connect. Check your connection parameters.');

mysql_select_db(MYSQL_DB, $db) or die(mysql_error($db));

$user_id = (isset($_GET['user_id'])) ? $_GET['user_id'] : '';
$ml_id = (isset($_GET['ml_id'])) ? $_GET['ml_id'] : '';
$type = (isset($_GET['type'])) ? $_GET['type'] : '';

if (empty($user_id)) {
    die('No user id available.');
}
$query = 'SELECT first_name, email FROM ml_users WHERE user_id = ' .
    $user_id;
$result = mysql_query($query, $db) or die(mysql_error());

if (mysql_num_rows($result) > 0) {
    $row = mysql_fetch_assoc($result);
    $first_name = $row['first_name'];
    $email = $row['email'];       
} else {
    die('No match for user id.');
}
mysql_free_result($result);

if (empty($ml_id)) {
    die('No mailing list id available.');
}
$query = 'SELECT listname FROM ml_lists WHERE ml_id = ' . $ml_id;
$result = mysql_query($query, $db) or die(mysql_error());

if (mysql_num_rows($result)) {
    $row = mysql_fetch_assoc($result);
    $listname = $row['listname'];
} else {
    die ('No match for mailing list id');
}
mysql_free_result($result);

if ($type == 'c') {
    echo '<h1>Thank You ' . $first_name . '</h1>';
    echo '<p>A confirmation for subscribing to the ' . $listname . ' mailing list ' . 
        'has been sent to ' . $email . '.</p>';
} else {
    echo '<h1>Thank You ' . $first_name . '</h1>';
    echo '<p>Thank you for subscribing to the ' . $listname . ' mailing list.</p>';
}
?>
 </body>
</html>
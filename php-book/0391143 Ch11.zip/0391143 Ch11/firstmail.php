<?php
mail('myaddress@example.com', 'Hello World',
    'Hi, world. Prepare for our arrival. We are starving!');
?>
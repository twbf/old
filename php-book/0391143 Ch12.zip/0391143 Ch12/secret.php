<?php
include 'auth.inc.php';
?>
<html>
 <head>
  <title>Secret</title>
 </head>
 <body>
  <h1>You've found my secret!</h1>
 </body>
</html>
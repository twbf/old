<html>
 <head>
  <title>Cookies Test</title>
 </head>
 <body>
  <h1>This is the Cookies Test Page</h1>
  <p><a href="cookies_set.php">Set Cookies</a></p>
  <p><a href="cookies_view.php">View Cookies</a></p>
  <p><a href="cookies_Delete.php">Delete Cookies</a></p>
 </body>
</html>
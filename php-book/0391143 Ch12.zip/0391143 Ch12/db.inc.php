<?php
define('MYSQL_HOST','localhost');
define('MYSQL_USER','bp6am');
define('MYSQL_PASSWORD','bp6ampass');
define('MYSQL_DB','comicbook_fansite');
?>
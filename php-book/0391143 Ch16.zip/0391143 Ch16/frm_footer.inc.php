  <p><?php echo $admin['copyright']['value']; ?></p>
 </body>
</html>